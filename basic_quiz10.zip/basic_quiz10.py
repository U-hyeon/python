# quiz) 프로젝트 내에 나만의 시그니쳐를 남기는 모듈을 만드시오

# 조건 : 모듈 파일명을 byme.py로 작성

import byme
byme.sign()