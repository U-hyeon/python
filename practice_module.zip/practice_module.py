# import theater_module
# theater_module.price(3) # 3명이서 영화보러갔을때 가격
# theater_module.price_morning(4) # 4명이서 조조영화보러갔을때 가격
# theater_module.price_soldier(5) # 군인 5명이서 영화보러갔을때 가격

# import theater_module as mv # as = define 처럼 사용
# mv.price(3)
# mv.price_morning(4)
# mv.price_soldier(5)

# from theater_module import * # 함수를 직접사용가능
# # from random import *
# price(3)
# price_morning(4)
# price_soldier(5)

# from theater_module import price, price_morning
# price(5)
# price_morning(6)
# #price_soldier(4) # 사용불가

from theater_module import price_soldier as price
price(5)